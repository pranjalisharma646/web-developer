
import HabitTracker from '../components/HabitTracker';

const Index = () => {
  return <HabitTracker />;
};

export default Index;
