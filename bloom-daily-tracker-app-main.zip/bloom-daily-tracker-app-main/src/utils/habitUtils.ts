
import { Habit, HabitStats, Achievement, HabitCategory } from '../types/habit';
import { format, startOfWeek, endOfWeek, eachDayOfInterval, isToday, parseISO, differenceInDays } from 'date-fns';

export const getDateString = (date: Date): string => {
  return format(date, 'yyyy-MM-dd');
};

export const isHabitCompletedToday = (habit: Habit): boolean => {
  const today = getDateString(new Date());
  return habit.completedDates.includes(today);
};

export const getHabitStreak = (habit: Habit): number => {
  if (habit.completedDates.length === 0) return 0;
  
  const sortedDates = habit.completedDates
    .map(date => parseISO(date))
    .sort((a, b) => b.getTime() - a.getTime());
  
  let streak = 0;
  let currentDate = new Date();
  
  for (const date of sortedDates) {
    const daysDiff = differenceInDays(currentDate, date);
    
    if (daysDiff === streak || (streak === 0 && daysDiff <= 1)) {
      streak++;
      currentDate = new Date(date.getTime() - 24 * 60 * 60 * 1000);
    } else {
      break;
    }
  }
  
  return streak;
};

export const getHabitStats = (habits: Habit[]): HabitStats => {
  const totalHabits = habits.length;
  const completedToday = habits.filter(isHabitCompletedToday).length;
  const longestStreak = Math.max(...habits.map(getHabitStreak), 0);
  const currentStreak = habits.reduce((sum, habit) => sum + getHabitStreak(habit), 0);
  
  const totalPossibleCompletions = habits.reduce((sum, habit) => {
    const daysSinceCreated = differenceInDays(new Date(), habit.createdAt) + 1;
    return sum + daysSinceCreated;
  }, 0);
  
  const totalCompletions = habits.reduce((sum, habit) => sum + habit.completedDates.length, 0);
  const completionRate = totalPossibleCompletions > 0 ? (totalCompletions / totalPossibleCompletions) * 100 : 0;
  
  // Weekly progress
  const weekStart = startOfWeek(new Date());
  const weekEnd = endOfWeek(new Date());
  const weekDays = eachDayOfInterval({ start: weekStart, end: weekEnd });
  
  const weeklyProgress = weekDays.map(day => {
    const dayString = getDateString(day);
    return habits.filter(habit => habit.completedDates.includes(dayString)).length;
  });
  
  return {
    totalHabits,
    completedToday,
    longestStreak,
    currentStreak,
    completionRate,
    weeklyProgress
  };
};

export const getDefaultAchievements = (): Achievement[] => [
  {
    id: '1',
    name: 'First Step',
    description: 'Complete your first habit',
    icon: '🌱',
    requirement: 1,
    type: 'total'
  },
  {
    id: '2',
    name: 'Week Warrior',
    description: 'Maintain a 7-day streak',
    icon: '🔥',
    requirement: 7,
    type: 'streak'
  },
  {
    id: '3',
    name: 'Consistency King',
    description: 'Maintain a 30-day streak',
    icon: '👑',
    requirement: 30,
    type: 'streak'
  },
  {
    id: '4',
    name: 'Health Enthusiast',
    description: 'Complete 20 health habits',
    icon: '💪',
    requirement: 20,
    type: 'category',
    category: HabitCategory.HEALTH
  },
  {
    id: '5',
    name: 'Productivity Pro',
    description: 'Complete 15 productivity habits',
    icon: '⚡',
    requirement: 15,
    type: 'category',
    category: HabitCategory.PRODUCTIVITY
  },
  {
    id: '6',
    name: 'Century Club',
    description: 'Complete 100 habits total',
    icon: '💯',
    requirement: 100,
    type: 'total'
  }
];

export const checkAchievements = (habits: Habit[], achievements: Achievement[]): Achievement[] => {
  const unlockedAchievements: Achievement[] = [];
  
  achievements.forEach(achievement => {
    if (achievement.unlockedAt) return;
    
    let isUnlocked = false;
    
    switch (achievement.type) {
      case 'total':
        const totalCompletions = habits.reduce((sum, habit) => sum + habit.completedDates.length, 0);
        isUnlocked = totalCompletions >= achievement.requirement;
        break;
      case 'streak':
        const maxStreak = Math.max(...habits.map(getHabitStreak), 0);
        isUnlocked = maxStreak >= achievement.requirement;
        break;
      case 'category':
        if (achievement.category) {
          const categoryCompletions = habits
            .filter(habit => habit.category === achievement.category)
            .reduce((sum, habit) => sum + habit.completedDates.length, 0);
          isUnlocked = categoryCompletions >= achievement.requirement;
        }
        break;
    }
    
    if (isUnlocked) {
      unlockedAchievements.push({
        ...achievement,
        unlockedAt: new Date()
      });
    }
  });
  
  return unlockedAchievements;
};

export const getCategoryColors = (): Record<HabitCategory, string> => ({
  [HabitCategory.HEALTH]: '#10b981',
  [HabitCategory.PRODUCTIVITY]: '#3b82f6',
  [HabitCategory.LEARNING]: '#8b5cf6',
  [HabitCategory.MINDFULNESS]: '#06b6d4',
  [HabitCategory.SOCIAL]: '#f59e0b',
  [HabitCategory.CREATIVE]: '#ef4444',
  [HabitCategory.FITNESS]: '#84cc16',
  [HabitCategory.FINANCE]: '#6366f1'
});
