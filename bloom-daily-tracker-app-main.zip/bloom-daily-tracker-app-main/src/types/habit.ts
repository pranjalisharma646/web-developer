
export interface Habit {
  id: string;
  name: string;
  category: HabitCategory;
  color: string;
  createdAt: Date;
  completedDates: string[];
  targetDays?: number;
  description?: string;
}

export enum HabitCategory {
  HEALTH = 'Health',
  PRODUCTIVITY = 'Productivity',
  LEARNING = 'Learning',
  MINDFULNESS = 'Mindfulness',
  SOCIAL = 'Social',
  CREATIVE = 'Creative',
  FITNESS = 'Fitness',
  FINANCE = 'Finance'
}

export interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  unlockedAt?: Date;
  requirement: number;
  type: 'streak' | 'total' | 'category';
  category?: HabitCategory;
}

export interface HabitStats {
  totalHabits: number;
  completedToday: number;
  longestStreak: number;
  currentStreak: number;
  completionRate: number;
  weeklyProgress: number[];
}
