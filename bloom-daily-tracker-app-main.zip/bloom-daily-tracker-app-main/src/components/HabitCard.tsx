
import React from 'react';
import { Habit, HabitCategory } from '../types/habit';
import { getHabitStreak, isHabitCompletedToday, getDateString } from '../utils/habitUtils';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, Circle, Flame } from 'lucide-react';

interface HabitCardProps {
  habit: Habit;
  onToggle: (habitId: string) => void;
}

const HabitCard: React.FC<HabitCardProps> = ({ habit, onToggle }) => {
  const isCompleted = isHabitCompletedToday(habit);
  const streak = getHabitStreak(habit);
  
  const getCategoryIcon = (category: HabitCategory): string => {
    const icons = {
      [HabitCategory.HEALTH]: '🏥',
      [HabitCategory.PRODUCTIVITY]: '⚡',
      [HabitCategory.LEARNING]: '📚',
      [HabitCategory.MINDFULNESS]: '🧘',
      [HabitCategory.SOCIAL]: '👥',
      [HabitCategory.CREATIVE]: '🎨',
      [HabitCategory.FITNESS]: '💪',
      [HabitCategory.FINANCE]: '💰'
    };
    return icons[category];
  };

  return (
    <Card className="transition-all duration-200 hover:shadow-md">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3 flex-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onToggle(habit.id)}
              className={`p-1 ${isCompleted ? 'text-green-600' : 'text-gray-400'}`}
            >
              {isCompleted ? (
                <CheckCircle className="h-6 w-6" />
              ) : (
                <Circle className="h-6 w-6" />
              )}
            </Button>
            
            <div className="flex-1">
              <div className="flex items-center space-x-2">
                <span className="text-lg">{getCategoryIcon(habit.category)}</span>
                <h3 className={`font-medium ${isCompleted ? 'line-through text-gray-500' : ''}`}>
                  {habit.name}
                </h3>
              </div>
              
              <div className="flex items-center space-x-2 mt-1">
                <Badge variant="secondary" className="text-xs">
                  {habit.category}
                </Badge>
                
                {streak > 0 && (
                  <div className="flex items-center space-x-1 text-orange-600">
                    <Flame className="h-3 w-3" />
                    <span className="text-xs font-medium">{streak}</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default HabitCard;
