
import React from 'react';
import { Achievement } from '../types/habit';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface AchievementBadgesProps {
  achievements: Achievement[];
}

const AchievementBadges: React.FC<AchievementBadgesProps> = ({ achievements }) => {
  const unlockedAchievements = achievements.filter(achievement => achievement.unlockedAt);
  const lockedAchievements = achievements.filter(achievement => !achievement.unlockedAt);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <span>🏆</span>
          <span>Achievements</span>
          <Badge variant="secondary">{unlockedAchievements.length}/{achievements.length}</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {unlockedAchievements.length > 0 && (
            <div>
              <h4 className="text-sm font-medium text-green-700 mb-2">Unlocked</h4>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                {unlockedAchievements.map(achievement => (
                  <div
                    key={achievement.id}
                    className="flex flex-col items-center p-3 bg-green-50 rounded-lg border border-green-200"
                  >
                    <div className="text-2xl mb-1">{achievement.icon}</div>
                    <div className="text-xs font-medium text-center">{achievement.name}</div>
                    <div className="text-xs text-gray-500 text-center mt-1">
                      {achievement.description}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {lockedAchievements.length > 0 && (
            <div>
              <h4 className="text-sm font-medium text-gray-700 mb-2">Locked</h4>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                {lockedAchievements.map(achievement => (
                  <div
                    key={achievement.id}
                    className="flex flex-col items-center p-3 bg-gray-50 rounded-lg border border-gray-200 opacity-60"
                  >
                    <div className="text-2xl mb-1 grayscale">{achievement.icon}</div>
                    <div className="text-xs font-medium text-center">{achievement.name}</div>
                    <div className="text-xs text-gray-500 text-center mt-1">
                      {achievement.description}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default AchievementBadges;
