
import React, { useState, useEffect } from 'react';
import { Habit, HabitCategory, Achievement } from '../types/habit';
import { getHabitStats, getDateString, getDefaultAchievements, checkAchievements, getCategoryColors } from '../utils/habitUtils';
import HabitCard from './HabitCard';
import AddHabitModal from './AddHabitModal';
import StatsCard from './StatsCard';
import MonthlyView from './MonthlyView';
import AchievementBadges from './AchievementBadges';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from '@/hooks/use-toast';
import { Calendar, BarChart3, Trophy, Plus } from 'lucide-react';

const HabitTracker: React.FC = () => {
  const [habits, setHabits] = useState<Habit[]>([]);
  const [achievements, setAchievements] = useState<Achievement[]>(getDefaultAchievements());
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedDate, setSelectedDate] = useState(new Date());

  // Load data from localStorage on component mount
  useEffect(() => {
    const savedHabits = localStorage.getItem('habits');
    const savedAchievements = localStorage.getItem('achievements');
    
    if (savedHabits) {
      try {
        const parsedHabits = JSON.parse(savedHabits).map((habit: any) => ({
          ...habit,
          createdAt: new Date(habit.createdAt)
        }));
        setHabits(parsedHabits);
      } catch (error) {
        console.error('Error parsing saved habits:', error);
      }
    }
    
    if (savedAchievements) {
      try {
        const parsedAchievements = JSON.parse(savedAchievements).map((achievement: any) => ({
          ...achievement,
          unlockedAt: achievement.unlockedAt ? new Date(achievement.unlockedAt) : undefined
        }));
        setAchievements(parsedAchievements);
      } catch (error) {
        console.error('Error parsing saved achievements:', error);
        setAchievements(getDefaultAchievements());
      }
    }
  }, []);

  // Save data to localStorage whenever habits or achievements change
  useEffect(() => {
    localStorage.setItem('habits', JSON.stringify(habits));
  }, [habits]);

  useEffect(() => {
    localStorage.setItem('achievements', JSON.stringify(achievements));
  }, [achievements]);

  const addHabit = (name: string, category: HabitCategory, description?: string) => {
    const colors = getCategoryColors();
    const newHabit: Habit = {
      id: Date.now().toString(),
      name,
      category,
      color: colors[category],
      createdAt: new Date(),
      completedDates: [],
      description
    };
    
    setHabits(prev => [...prev, newHabit]);
    toast({
      title: "Habit Added!",
      description: `"${name}" has been added to your habits.`,
    });
  };

  const toggleHabit = (habitId: string) => {
    const today = getDateString(new Date());
    
    setHabits(prev => {
      const updatedHabits = prev.map(habit => {
        if (habit.id === habitId) {
          const isCompleted = habit.completedDates.includes(today);
          const updatedDates = isCompleted
            ? habit.completedDates.filter(date => date !== today)
            : [...habit.completedDates, today];
          
          return {
            ...habit,
            completedDates: updatedDates
          };
        }
        return habit;
      });
      
      // Check for new achievements
      const newAchievements = checkAchievements(updatedHabits, achievements);
      if (newAchievements.length > 0) {
        setAchievements(prev => 
          prev.map(achievement => {
            const newAchievement = newAchievements.find(na => na.id === achievement.id);
            return newAchievement || achievement;
          })
        );
        
        newAchievements.forEach(achievement => {
          toast({
            title: "Achievement Unlocked! 🎉",
            description: `${achievement.icon} ${achievement.name}: ${achievement.description}`,
          });
        });
      }
      
      return updatedHabits;
    });
  };

  const filteredHabits = selectedCategory === 'all' 
    ? habits 
    : habits.filter(habit => habit.category === selectedCategory);

  const stats = getHabitStats(habits);

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <h1 className="text-4xl font-bold text-gray-900">Habit Tracker</h1>
          <p className="text-gray-600">Build lasting habits, one day at a time</p>
        </div>

        {/* Stats Overview */}
        <StatsCard stats={stats} />

        {/* Main Content */}
        <Tabs defaultValue="today" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="today" className="flex items-center space-x-2">
              <Plus className="h-4 w-4" />
              <span>Today</span>
            </TabsTrigger>
            <TabsTrigger value="calendar" className="flex items-center space-x-2">
              <Calendar className="h-4 w-4" />
              <span>Calendar</span>
            </TabsTrigger>
            <TabsTrigger value="insights" className="flex items-center space-x-2">
              <BarChart3 className="h-4 w-4" />
              <span>Insights</span>
            </TabsTrigger>
            <TabsTrigger value="achievements" className="flex items-center space-x-2">
              <Trophy className="h-4 w-4" />
              <span>Achievements</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="today" className="space-y-6">
            <div className="flex flex-col sm:flex-row gap-4 items-center">
              <div className="flex-1">
                <AddHabitModal onAddHabit={addHabit} />
              </div>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-full sm:w-48">
                  <SelectValue placeholder="Filter by category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  {Object.values(HabitCategory).map(category => (
                    <SelectItem key={category} value={category}>{category}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-3">
              {filteredHabits.length === 0 ? (
                <Card>
                  <CardContent className="flex flex-col items-center justify-center py-12 text-center">
                    <div className="text-6xl mb-4">🌱</div>
                    <h3 className="text-lg font-semibold mb-2">No habits yet</h3>
                    <p className="text-gray-600 mb-4">Start building positive habits today!</p>
                  </CardContent>
                </Card>
              ) : (
                filteredHabits.map(habit => (
                  <HabitCard
                    key={habit.id}
                    habit={habit}
                    onToggle={toggleHabit}
                  />
                ))
              )}
            </div>
          </TabsContent>

          <TabsContent value="calendar">
            <MonthlyView habits={habits} selectedDate={selectedDate} />
          </TabsContent>

          <TabsContent value="insights">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Category Breakdown</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {Object.values(HabitCategory).map(category => {
                      const categoryHabits = habits.filter(h => h.category === category);
                      const completedToday = categoryHabits.filter(h => 
                        h.completedDates.includes(getDateString(new Date()))
                      ).length;
                      
                      if (categoryHabits.length === 0) return null;
                      
                      const percentage = (completedToday / categoryHabits.length) * 100;
                      
                      return (
                        <div key={category} className="flex items-center justify-between">
                          <span className="text-sm font-medium">{category}</span>
                          <div className="flex items-center space-x-2">
                            <div className="w-24 h-2 bg-gray-200 rounded-full overflow-hidden">
                              <div 
                                className="h-full bg-green-500 rounded-full transition-all duration-300"
                                style={{ width: `${percentage}%` }}
                              />
                            </div>
                            <span className="text-sm text-gray-600 w-12">
                              {completedToday}/{categoryHabits.length}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Week Overview</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day, index) => (
                      <div key={day} className="flex items-center justify-between">
                        <span className="text-sm font-medium w-8">{day}</span>
                        <div className="flex items-center space-x-2 flex-1">
                          <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-blue-500 rounded-full transition-all duration-300"
                              style={{ 
                                width: `${habits.length > 0 ? (stats.weeklyProgress[index] / habits.length) * 100 : 0}%`
                              }}
                            />
                          </div>
                          <span className="text-sm text-gray-600 w-8">
                            {stats.weeklyProgress[index]}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="achievements">
            <AchievementBadges achievements={achievements} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default HabitTracker;
