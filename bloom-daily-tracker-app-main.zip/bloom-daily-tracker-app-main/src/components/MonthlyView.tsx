
import React from 'react';
import { Habit } from '../types/habit';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isSameDay } from 'date-fns';
import { getDateString } from '../utils/habitUtils';

interface MonthlyViewProps {
  habits: Habit[];
  selectedDate: Date;
}

const MonthlyView: React.FC<MonthlyViewProps> = ({ habits, selectedDate }) => {
  const monthStart = startOfMonth(selectedDate);
  const monthEnd = endOfMonth(selectedDate);
  const monthDays = eachDayOfInterval({ start: monthStart, end: monthEnd });
  
  const getCompletionRate = (date: Date): number => {
    if (!isSameMonth(date, selectedDate)) return 0;
    
    const dateString = getDateString(date);
    const completedHabits = habits.filter(habit => 
      habit.completedDates.includes(dateString)
    ).length;
    
    return habits.length > 0 ? (completedHabits / habits.length) * 100 : 0;
  };
  
  const getIntensityClass = (rate: number): string => {
    if (rate === 0) return 'bg-gray-100';
    if (rate <= 25) return 'bg-green-100';
    if (rate <= 50) return 'bg-green-200';
    if (rate <= 75) return 'bg-green-300';
    return 'bg-green-400';
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-center">
          {format(selectedDate, 'MMMM yyyy')}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-7 gap-1 mb-4">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
            <div key={day} className="text-center text-sm font-medium text-gray-500 p-2">
              {day}
            </div>
          ))}
        </div>
        
        <div className="grid grid-cols-7 gap-1">
          {monthDays.map((date, index) => {
            const completionRate = getCompletionRate(date);
            const isToday = isSameDay(date, new Date());
            
            return (
              <div
                key={index}
                className={`
                  aspect-square flex items-center justify-center text-sm rounded-md cursor-pointer
                  transition-all duration-200 hover:scale-105
                  ${getIntensityClass(completionRate)}
                  ${isToday ? 'ring-2 ring-blue-500' : ''}
                  ${!isSameMonth(date, selectedDate) ? 'opacity-30' : ''}
                `}
                title={`${format(date, 'MMM d')}: ${Math.round(completionRate)}% completion`}
              >
                <span className={`font-medium ${completionRate > 50 ? 'text-white' : 'text-gray-700'}`}>
                  {format(date, 'd')}
                </span>
              </div>
            );
          })}
        </div>
        
        <div className="flex items-center justify-center space-x-2 mt-4 text-xs text-gray-500">
          <span>Less</span>
          <div className="flex space-x-1">
            <div className="w-3 h-3 bg-gray-100 rounded-sm"></div>
            <div className="w-3 h-3 bg-green-100 rounded-sm"></div>
            <div className="w-3 h-3 bg-green-200 rounded-sm"></div>
            <div className="w-3 h-3 bg-green-300 rounded-sm"></div>
            <div className="w-3 h-3 bg-green-400 rounded-sm"></div>
          </div>
          <span>More</span>
        </div>
      </CardContent>
    </Card>
  );
};

export default MonthlyView;
